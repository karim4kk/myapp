import 'package:flutter/material.dart';

void main() => runApp(const CalculatorApp());

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _output = "0";
  String _currentValue = "";
  double _num1 = 0;
  double _num2 = 0;
  String _operand = "";

  void _buttonPressed(String btnText) {
    if (btnText == "C") {
      _output = "0";
      _currentValue = "";
      _num1 = 0;
      _num2 = 0;
      _operand = "";
    } else if (btnText == "+" || btnText == "-" || btnText == "*" || btnText == "/") {
      _num1 = double.parse(_output);
      _operand = btnText;
      _currentValue = "";
    } else if (btnText == "=") {
      _num2 = double.parse(_output);
      if (_operand == "+") _output = (_num1 + _num2).toString();
      if (_operand == "-") _output = (_num1 - _num2).toString();
      if (_operand == "*") _output = (_num1 * _num2).toString();
      if (_operand == "/") _output = (_num1 / _num2).toString();
      _num1 = 0;
      _num2 = 0;
      _operand = "";
      _currentValue = _output;
    } else {
      _currentValue += btnText;
      _output = _currentValue;
    }

    setState(() {});
  }

  Widget _buildButton(String text, Color color) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.all(24),
            backgroundColor: color,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          ),
          onPressed: () => _buttonPressed(text),
          child: Text(text, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('آلة حاسبة ذكية')),
      body: Column(
        children: [
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              padding: const EdgeInsets.all(24),
              child: Text(_output, style: const TextStyle(fontSize: 60, fontWeight: FontWeight.bold)),
            ),
          ),
          Column(
            children: [
              Row(children: [_buildButton("7", Colors.grey[800]!), _buildButton("8", Colors.grey[800]!), _buildButton("9", Colors.grey[800]!), _buildButton("/", Colors.orange)]),
              Row(children: [_buildButton("4", Colors.grey[800]!), _buildButton("5", Colors.grey[800]!), _buildButton("6", Colors.grey[800]!), _buildButton("*", Colors.orange)]),
              Row(children: [_buildButton("1", Colors.grey[800]!), _buildButton("2", Colors.grey[800]!), _buildButton("3", Colors.grey[800]!), _buildButton("-", Colors.orange)]),
              Row(children: [_buildButton("C", Colors.redAccent), _buildButton("0", Colors.grey[800]!), _buildButton("=", Colors.green), _buildButton("+", Colors.orange)]),
            ],
          )
        ],
      ),
    );
  }
}
